document.getElementById('viewResults').addEventListener('click', function () {
    window.location.href = 'viewResults.html';
 });
 
 document.getElementById('searchByName').addEventListener('click', function () {
    window.location.href = 'searchByName.html';
 });
 
 document.getElementById('logout').addEventListener('click', function () {
    window.location.href = 'index.html'; // Redirect to the main page
 });
 