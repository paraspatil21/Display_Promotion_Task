document.getElementById('viewGrades').addEventListener('click', function () {
    window.location.href = 'viewGrades.html';
 });
 
 document.getElementById('viewAssignments').addEventListener('click', function () {
    window.location.href = 'viewAssignments.html';
 });
 
 document.getElementById('logout').addEventListener('click', function () {
    window.location.href = 'index.html'; // Redirect to the main page
 });
 