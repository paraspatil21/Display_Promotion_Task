document.getElementById('uploadResults').addEventListener('click', function () {
   window.location.href = 'uploadResults.html';
});

document.getElementById('editResults').addEventListener('click', function () {
   window.location.href = 'editResults.html';
});

document.getElementById('validateRecords').addEventListener('click', function () {
   window.location.href = 'validateRecords.html';
});

document.getElementById('logout').addEventListener('click', function () {
   window.location.href = 'index.html';
});
