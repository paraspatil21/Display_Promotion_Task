document.getElementById('viewResults').addEventListener('click', function () {
   window.location.href = 'viewResults.html';
});


document.getElementById('downloadResults').addEventListener('click', function () {
   window.location.href = 'downloadResults.html';
});

document.getElementById('logout').addEventListener('click', function () {
   window.location.href = 'index.html';
});
