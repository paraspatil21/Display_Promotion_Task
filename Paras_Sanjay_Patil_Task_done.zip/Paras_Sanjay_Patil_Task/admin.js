document.getElementById('manageRecords').addEventListener('click', function () {
    window.location.href = 'manageRecords.html';
 });
 
 document.getElementById('createCredentials').addEventListener('click', function () {
    window.location.href = 'createCredentials.html';
 });
 
 document.getElementById('monitorActivity').addEventListener('click', function () {
    window.location.href = 'monitorActivity.html';
 });
 
 document.getElementById('logout').addEventListener('click', function () {
    window.location.href = 'index.html'; // Redirect to the main page
 });
 